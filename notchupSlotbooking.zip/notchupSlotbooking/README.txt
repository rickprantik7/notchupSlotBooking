******Opening Mongodb********
1. Open command prompt
2. Type mongod

##-You need have mongodb installed in your system

*****Intializing  node components and running node server********
1. Open command prompt
2. Type cd space then the required folder
3. Type npm init -y
4. type npm i
5. type nodemon app.js or node app.js any one suitable


******Browser*****
1  open Browser
2. type in the url bar localhost:3000
3. As the page opens you will see a form section enter the
required values and submit
4. check log for required results
### In the navbar the dropdown menus are only set they aren't set with any links
