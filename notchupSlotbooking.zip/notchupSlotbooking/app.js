const express= require('express')
const mongoose= require('mongoose')
const bodyParser= require('body-parser')
const ejs= require('ejs')
const fetch= require('node-fetch')
const app= express()
app.set('view engine','ejs')
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))
mongoose.connect("mongodb://localhost:27017/coursedb",{newUrlParser:true})
const courseSchema = new mongoose.Schema({
  parentName:String,
  parentContact:String,
  parentEmail:String,
  childName:String,
  childAge:Number,
  course:String,
  date:Date,
  })
const date= new Date()
const today= new Date()
const maxDate=date.setDate(date.getDate()+ 7)
const course= mongoose.model("course",courseSchema)
const hours= today.getHours()+4
const time=hours+":"+today.getMinutes()

function dateChange(Date){

  const dmonth="0"+Date.getMonth()
  const ddate="0"+Date.getDate()
 if(dmonth.length==2){
     	if(ddate.length==2){
        const x=Date.getMonth()+1
     		return Date.getFullYear()+"-0"+x+"-0"+Date.getDate();

       }
     else{
       const x=Date.getMonth()+1
       return Date.getFullYear()+"-0"+x+"-"+Date.getDate();

     }

     }
     else{
     	if(ddate.length==2){
        const x=Date.getMonth()+1
     	return Date.getFullYear()+"-"+x+"-0"+Date.getDate();

      }
     else{
       const x=Date.getMonth()+1
       return Date.getFullYear()+"-"+x+"-"+Date.getDate();

 }
}
}

app.get("/",function(req,res){
const todays=dateChange(today)
const dates=dateChange(date)
  res.render('index',{min:todays,max:dates,mint:time})



})
app.post("/",function(req,res){
  fetch('https://script.google.com/macros/s/AKfycbzJ8Nn2ytbGO8QOkGU1kfU9q50RjDHje4Ysphyesyh-osS76wep/exec')
 .then((resp) => resp.json())
 .then(function(data){
   data.forEach(function(items){
    if(req.body.course==items.course_name){
      const parent= new course({
        parentName:req.body.pname,
        parentContact:req.body.pnumber,
        parentEmail:req.body.peamil,
        childName:req.body.cname,
        childAge:req.body.cage,
        course:req.body.course,
        date:req.body.date,
         })
      parent.save(function(err){
        if(!err){
          console.log("slots given succesfully");
        }
      })
      console.log(parent);
      console.log("Having slot number"+items.slots[0].slot);
       setTimeout(function(){
         slot=items.slots[0].slot
         var par=[parent,slot]
         console.log(par);
       },3600000)
  }
   })
 })
})


app.listen(3000,function(){
  console.log("server is running");
})
